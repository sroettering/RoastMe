var require = meteorInstall({"imports":{"modules":{"accounts":{"server":{"configure-services.js":["meteor/meteor","meteor/service-configuration",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// imports/modules/accounts/server/configure-services.js                                                         //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var ServiceConfiguration;module.import('meteor/service-configuration',{"ServiceConfiguration":function(v){ServiceConfiguration=v}});
                                                                                                                 // 2
                                                                                                                 //
var services = Meteor.settings['private'].oAuth;                                                                 // 4
                                                                                                                 //
var configure = function configure() {                                                                           // 6
  if (services) {                                                                                                // 7
    for (var service in meteorBabelHelpers.sanitizeForInObject(services)) {                                      // 8
      ServiceConfiguration.configurations.upsert({ service: service }, {                                         // 9
        $set: services[service]                                                                                  // 10
      });                                                                                                        // 9
    }                                                                                                            // 12
  }                                                                                                              // 13
};                                                                                                               // 14
                                                                                                                 //
configure();                                                                                                     // 16
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"methods.js":["meteor/meteor","meteor/check","/imports/modules/roasts/roasts-collection","/imports/modules/roasts/comments-collection",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// imports/modules/accounts/server/methods.js                                                                    //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var check;module.import('meteor/check',{"check":function(v){check=v}});var Roasts;module.import('/imports/modules/roasts/roasts-collection',{"Roasts":function(v){Roasts=v}});var Comments;module.import('/imports/modules/roasts/comments-collection',{"Comments":function(v){Comments=v}});
                                                                                                                 // 2
                                                                                                                 //
                                                                                                                 // 4
                                                                                                                 // 5
                                                                                                                 //
Meteor.methods({                                                                                                 // 7
  acceptRulesAndTos: function () {                                                                               // 8
    function acceptRulesAndTos() {                                                                               // 7
      if (!this.userId) return;                                                                                  // 9
      Meteor.users.update({ _id: this.userId }, {                                                                // 10
        $set: {                                                                                                  // 12
          rulesAccepted: true,                                                                                   // 13
          tosAccepted: true                                                                                      // 14
        }                                                                                                        // 12
      });                                                                                                        // 11
    }                                                                                                            // 18
                                                                                                                 //
    return acceptRulesAndTos;                                                                                    // 7
  }(),                                                                                                           // 7
  changeUsername: function () {                                                                                  // 19
    function changeUsername(username) {                                                                          // 7
      check(username, String);                                                                                   // 20
      if (!this.userId) return;                                                                                  // 21
      Meteor.users.update({ _id: this.userId }, {                                                                // 22
        $set: {                                                                                                  // 24
          "profile.name": username                                                                               // 25
        }                                                                                                        // 24
      });                                                                                                        // 23
      Roasts.update({ userId: this.userId }, {                                                                   // 29
        $set: {                                                                                                  // 31
          userName: username                                                                                     // 32
        }                                                                                                        // 31
      }, { multi: true });                                                                                       // 30
      Comments.update({ userId: this.userId }, {                                                                 // 35
        $set: {                                                                                                  // 37
          userName: username                                                                                     // 38
        }                                                                                                        // 37
      }, { multi: true });                                                                                       // 36
    }                                                                                                            // 41
                                                                                                                 //
    return changeUsername;                                                                                       // 7
  }()                                                                                                            // 7
});                                                                                                              // 7
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"publications.js":["meteor/meteor","meteor/check","meteor/alanning:roles",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// imports/modules/accounts/server/publications.js                                                               //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var check;module.import('meteor/check',{"check":function(v){check=v}});var Roles;module.import('meteor/alanning:roles',{"Roles":function(v){Roles=v}});
                                                                                                                 // 2
                                                                                                                 // 3
                                                                                                                 //
Meteor.publish('user.current', function () {                                                                     // 5
  return Meteor.users.find({ _id: this.userId }, {                                                               // 6
    fields: {                                                                                                    // 7
      profile: 1,                                                                                                // 8
      'services.facebook.picture': 1,                                                                            // 9
      'services.google.picture': 1,                                                                              // 10
      roles: 1,                                                                                                  // 11
      createdAt: 1,                                                                                              // 12
      rulesAccepted: 1,                                                                                          // 13
      tosAccepted: 1                                                                                             // 14
    }                                                                                                            // 7
  });                                                                                                            // 6
});                                                                                                              // 17
                                                                                                                 //
Meteor.publish('user.profile', function (userId) {                                                               // 19
  check(userId, String);                                                                                         // 20
  return Meteor.users.find({ _id: userId }, {                                                                    // 21
    fields: {                                                                                                    // 22
      profile: 1,                                                                                                // 23
      'services.facebook.picture': 1,                                                                            // 24
      'services.google.picture': 1,                                                                              // 25
      createdAt: 1                                                                                               // 26
    }                                                                                                            // 22
  });                                                                                                            // 21
});                                                                                                              // 29
                                                                                                                 //
Meteor.publish('user.all', function () {                                                                         // 31
  var user = Meteor.users.find({ _id: this.userId });                                                            // 32
  if (Roles.userIsInRole(user, 'admin')) {                                                                       // 33
    return Meteor.users.find({}, { fields: {                                                                     // 34
        profile: 1,                                                                                              // 35
        'services.facebook.picture': 1,                                                                          // 36
        'services.google.picture': 1,                                                                            // 37
        createdAt: 1,                                                                                            // 38
        roles: 1                                                                                                 // 39
      }                                                                                                          // 34
    });                                                                                                          // 34
  } else {                                                                                                       // 42
    this.ready();                                                                                                // 43
  }                                                                                                              // 44
});                                                                                                              // 45
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"social-login-helpers.js":["meteor/meteor","meteor/http",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// imports/modules/accounts/server/social-login-helpers.js                                                       //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var HTTP;module.import('meteor/http',{"HTTP":function(v){HTTP=v}});
                                                                                                                 // 2
                                                                                                                 //
Meteor.methods({                                                                                                 // 4
  addGoogleAgeRange: function () {                                                                               // 5
    function addGoogleAgeRange() {                                                                               // 4
      var _this = this;                                                                                          // 5
                                                                                                                 //
      if (Meteor.user() && Meteor.user().services.google) {                                                      // 6
        var userId = Meteor.user().services.google.id;                                                           // 7
        var url = 'https://www.googleapis.com/plus/v1/people/' + userId;                                         // 8
        var params = {                                                                                           // 9
          access_token: Meteor.user().services.google.accessToken                                                // 10
        };                                                                                                       // 9
        HTTP.get(url, { params: params }, function (err, result) {                                               // 12
          if (err) {                                                                                             // 13
            console.log(err.message);                                                                            // 14
          } else {                                                                                               // 15
            Meteor.users.update(_this.userId, { $set: { "services.google.age_range": result.data.ageRange } });  // 16
          }                                                                                                      // 17
        });                                                                                                      // 18
      }                                                                                                          // 19
    }                                                                                                            // 20
                                                                                                                 //
    return addGoogleAgeRange;                                                                                    // 4
  }(),                                                                                                           // 4
  addFacebookImage: function () {                                                                                // 21
    function addFacebookImage() {                                                                                // 4
      var _this2 = this;                                                                                         // 21
                                                                                                                 //
      if (Meteor.user() && Meteor.user().services.facebook) {                                                    // 22
        var userId = Meteor.user().services.facebook.id;                                                         // 23
        var url = 'http://graph.facebook.com/v2.8/' + userId + '/picture';                                       // 24
        var params = {                                                                                           // 25
          redirect: false,                                                                                       // 26
          type: 'small',                                                                                         // 27
          height: 400                                                                                            // 28
        };                                                                                                       // 25
        HTTP.get(url, { params: params }, function (err, result) {                                               // 30
          if (err) {                                                                                             // 31
            console.log(err.message);                                                                            // 32
          } else {                                                                                               // 33
            Meteor.users.update(_this2.userId, { $set: { "services.facebook.picture": result.data.data.url } });
          }                                                                                                      // 35
        });                                                                                                      // 36
      }                                                                                                          // 37
    }                                                                                                            // 38
                                                                                                                 //
    return addFacebookImage;                                                                                     // 4
  }()                                                                                                            // 4
});                                                                                                              // 4
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"users-schema.js":["meteor/meteor","meteor/aldeed:simple-schema","/imports/modules/utility/schema-commons.js","/imports/modules/roasts/roasts-collection","/imports/modules/roasts/comments-collection",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// imports/modules/accounts/server/users-schema.js                                                               //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
module.export({UsersSchema:function(){return UsersSchema}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var SchemaCommons;module.import('/imports/modules/utility/schema-commons.js',{"SchemaCommons":function(v){SchemaCommons=v}});var Roasts;module.import('/imports/modules/roasts/roasts-collection',{"Roasts":function(v){Roasts=v}});var Comments;module.import('/imports/modules/roasts/comments-collection',{"Comments":function(v){Comments=v}});
                                                                                                                 // 2
                                                                                                                 //
                                                                                                                 // 4
                                                                                                                 // 5
                                                                                                                 // 6
                                                                                                                 //
var UserProfile = new SimpleSchema({                                                                             // 8
  name: {                                                                                                        // 9
    type: String                                                                                                 // 10
  }                                                                                                              // 9
});                                                                                                              // 8
                                                                                                                 //
var UsersSchema = new SimpleSchema({                                                                             // 14
  profile: {                                                                                                     // 15
    type: UserProfile                                                                                            // 16
  },                                                                                                             // 15
  roles: {                                                                                                       // 18
    type: Array,                                                                                                 // 19
    optional: true                                                                                               // 20
  },                                                                                                             // 18
  'roles.$': {                                                                                                   // 22
    type: String                                                                                                 // 23
  },                                                                                                             // 22
  services: {                                                                                                    // 25
    type: Object,                                                                                                // 26
    optional: true,                                                                                              // 27
    blackbox: true                                                                                               // 28
  },                                                                                                             // 25
  createdAt: SchemaCommons.createdAt,                                                                            // 30
  updatedAt: SchemaCommons.updatedAt,                                                                            // 31
  rulesAccepted: {                                                                                               // 32
    type: Boolean,                                                                                               // 33
    autoValue: function () {                                                                                     // 34
      function autoValue() {                                                                                     // 32
        if (this.isInsert) {                                                                                     // 35
          return false;                                                                                          // 36
        }                                                                                                        // 37
      }                                                                                                          // 38
                                                                                                                 //
      return autoValue;                                                                                          // 32
    }()                                                                                                          // 32
  },                                                                                                             // 32
  tosAccepted: {                                                                                                 // 40
    type: Boolean,                                                                                               // 41
    autoValue: function () {                                                                                     // 42
      function autoValue() {                                                                                     // 40
        if (this.isInsert) {                                                                                     // 43
          return false;                                                                                          // 44
        }                                                                                                        // 45
      }                                                                                                          // 46
                                                                                                                 //
      return autoValue;                                                                                          // 40
    }()                                                                                                          // 40
  },                                                                                                             // 40
  status: {                                                                                                      // 48
    type: String,                                                                                                // 49
    allowedValues: ['active', 'cautioned', 'banned'],                                                            // 50
    autoValue: function () {                                                                                     // 51
      function autoValue() {                                                                                     // 48
        if (this.isInsert) {                                                                                     // 52
          return 'active';                                                                                       // 53
        }                                                                                                        // 54
      }                                                                                                          // 55
                                                                                                                 //
      return autoValue;                                                                                          // 48
    }()                                                                                                          // 48
  },                                                                                                             // 48
  heartbeat: {                                                                                                   // 57
    type: Date,                                                                                                  // 58
    optional: true                                                                                               // 59
  }                                                                                                              // 57
});                                                                                                              // 14
                                                                                                                 //
Meteor.users.attachSchema(UsersSchema);                                                                          // 63
                                                                                                                 //
Meteor.users.after.update(function (userId, doc) {                                                               // 65
  var userImage = doc.services.facebook ? doc.services.facebook.picture : doc.services.google ? doc.services.google.picture : '';
  Roasts.update({ userId: userId }, { $set: { userImage: userImage } }, { multi: true });                        // 67
  Comments.update({ userId: userId }, { $set: { userImage: userImage } }, { multi: true });                      // 68
});                                                                                                              // 69
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},"admin":{"server":{"fixtures.js":["meteor/meteor","meteor/alanning:roles",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// imports/modules/admin/server/fixtures.js                                                                      //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Roles;module.import('meteor/alanning:roles',{"Roles":function(v){Roles=v}});
                                                                                                                 // 2
                                                                                                                 //
// all accounts associated with these email adresses receive admin rights                                        // 4
var adminEmails = ['svenroettering@web.de', 'king78176@yahoo.de', 'Rosenboom.benjamin@aol.com', 'k-wiese@web.de', 'facebook@tim-tilch.de'];
                                                                                                                 //
/*                                                                                                               // 13
const makeAdmins = () => {                                                                                       //
  adminEmails.forEach((email) => {                                                                               //
    let user = Meteor.users.findOne({                                                                            //
      $or: [                                                                                                     //
        { 'services.facebook.email': email },                                                                    //
        { 'services.google.email': email },                                                                      //
      ],                                                                                                         //
    });                                                                                                          //
                                                                                                                 //
    if (user) {                                                                                                  //
      Roles.addUsersToRoles(user, 'admin');                                                                      //
    }                                                                                                            //
  });                                                                                                            //
}                                                                                                                //
*/                                                                                                               //
                                                                                                                 //
var giveRoles = function giveRoles(userId, doc) {                                                                // 30
  var email = doc.services.facebook ? doc.services.facebook.email : doc.services.google ? doc.services.google.email : '';
  if (adminEmails.includes(email)) {                                                                             // 32
    Roles.addUsersToRoles(doc, 'admin');                                                                         // 33
  } else {                                                                                                       // 34
    Roles.addUsersToRoles(doc, 'user');                                                                          // 35
  }                                                                                                              // 36
};                                                                                                               // 37
                                                                                                                 //
Meteor.users.after.insert(function (userId, doc) {                                                               // 39
  giveRoles(userId, doc);                                                                                        // 40
});                                                                                                              // 41
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"publications.js":["meteor/meteor","meteor/random","meteor/check","meteor/momentjs:moment",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// imports/modules/admin/server/publications.js                                                                  //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Random;module.import('meteor/random',{"Random":function(v){Random=v}});var check;module.import('meteor/check',{"check":function(v){check=v}});var moment;module.import('meteor/momentjs:moment',{"moment":function(v){moment=v}});
                                                                                                                 // 2
                                                                                                                 // 3
                                                                                                                 // 4
                                                                                                                 //
function getDayDifference(date1, date2) {                                                                        // 6
  date1.setHours(12, 0, 0, 0);                                                                                   // 7
  date2.setHours(12, 0, 0, 0);                                                                                   // 8
  var timeDiff = Math.abs(date2.getTime() - date1.getTime());                                                    // 9
  var diffDays = Math.floor(timeDiff / (1000 * 3600 * 24));                                                      // 10
  return diffDays;                                                                                               // 11
}                                                                                                                // 12
/*                                                                                                               // 13
Meteor.publish('usersPerDay', function (historyLength) {                                                         //
  check(historyLength, Number);                                                                                  //
  const self = this;                                                                                             //
  const tempId = Random.id();                                                                                    //
  const dateLimit = new Date();                                                                                  //
  dateLimit.setHours(12, 0, 0, 0);                                                                               //
  dateLimit.setDate(dateLimit.getDate() - (historyLength - 1));                                                  //
  const curDate = moment(dateLimit);                                                                             //
  const stats = {                                                                                                //
    userDeltas: [],                                                                                              //
    labels: [],                                                                                                  //
    updatedAt: new Date(),                                                                                       //
  };                                                                                                             //
                                                                                                                 //
  for (let i = 0; i < historyLength; i++) {                                                                      //
    stats.userDeltas.push(0);                                                                                    //
    stats.labels.push(curDate.format('DD.MM.YY'));                                                               //
    curDate.add(1, 'd');                                                                                         //
  }                                                                                                              //
                                                                                                                 //
  self.added('userStats', tempId, stats);                                                                        //
                                                                                                                 //
  const userHandle = Meteor.users.find({ createdAt: { $gte: dateLimit } }, { sort: { createdAt: 1 } }).observeChanges({
    added(id, doc) {                                                                                             //
      const day = getDayDifference(dateLimit, doc.createdAt);                                                    //
      stats.userDeltas[day]++;                                                                                   //
      stats.updatedAt = new Date();                                                                              //
      self.changed('userStats', tempId, stats);                                                                  //
    },                                                                                                           //
    removed() {                                                                                                  //
      const day = historyLength - 1;                                                                             //
      stats.userDeltas[day]--;                                                                                   //
      stats.updatedAt = new Date();                                                                              //
      self.changed('userStats', tempId, stats);                                                                  //
    },                                                                                                           //
  });                                                                                                            //
                                                                                                                 //
  this.ready();                                                                                                  //
  self.onStop(() => {                                                                                            //
    userHandle.stop();                                                                                           //
  });                                                                                                            //
});                                                                                                              //
*/                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},"roasts":{"server":{"configure-slingshot.js":["meteor/meteor","meteor/edgee:slingshot","/imports/modules/roasts/roasts-collection",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// imports/modules/roasts/server/configure-slingshot.js                                                          //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Slingshot;module.import('meteor/edgee:slingshot',{"Slingshot":function(v){Slingshot=v}});var Roasts;module.import('/imports/modules/roasts/roasts-collection',{"Roasts":function(v){Roasts=v}});
                                                                                                                 // 2
                                                                                                                 //
                                                                                                                 // 4
                                                                                                                 //
Slingshot.createDirective("uploadRoastImgS3", Slingshot.S3Storage, {                                             // 6
  region: "eu-central-1",                                                                                        // 7
  bucket: "itsroastme",                                                                                          // 8
  acl: "public-read",                                                                                            // 9
  authorize: function () {                                                                                       // 10
    function authorize() {                                                                                       // 6
      return Meteor.userId();                                                                                    // 11
    }                                                                                                            // 12
                                                                                                                 //
    return authorize;                                                                                            // 6
  }(),                                                                                                           // 6
  key: function () {                                                                                             // 13
    function key(file) {                                                                                         // 6
      var imageUrl = process.env.NODE_ENV + '/' + Meteor.userId() + '/roasts/' + file.name;                      // 14
      var roast = Roasts.findOne({ imageUrl: imageUrl });                                                        // 15
      if (roast) throw new Meteor.Error("duplicate-roast", "This file already exists!");                         // 16
      return imageUrl;                                                                                           // 17
    }                                                                                                            // 18
                                                                                                                 //
    return key;                                                                                                  // 6
  }()                                                                                                            // 6
});                                                                                                              // 6
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"fixtures.js":["meteor/random","meteor/digilord:faker","/imports/modules/utility/seeder","../roasts-collection","../comments-collection",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// imports/modules/roasts/server/fixtures.js                                                                     //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
var Random;module.import('meteor/random',{"Random":function(v){Random=v}});var faker;module.import('meteor/digilord:faker',{"faker":function(v){faker=v}});var Seed;module.import('/imports/modules/utility/seeder',{"default":function(v){Seed=v}});var Roasts;module.import('../roasts-collection',{"Roasts":function(v){Roasts=v}});var Comments;module.import('../comments-collection',{"Comments":function(v){Comments=v}});
                                                                                                                 // 2
                                                                                                                 //
                                                                                                                 // 4
                                                                                                                 // 5
                                                                                                                 // 6
                                                                                                                 //
var createRoasts = function createRoasts() {                                                                     // 8
  Seed('roasts', {                                                                                               // 9
    num: 20,                                                                                                     // 10
    ignoreExistingData: false,                                                                                   // 11
    environments: ['development'],                                                                               // 12
    model: function () {                                                                                         // 13
      function model(index) {                                                                                    // 9
        return {                                                                                                 // 14
          title: faker.lorem.sentence(),                                                                         // 15
          userId: faker.random.uuid(),                                                                           // 16
          userName: faker.internet.userName(),                                                                   // 17
          userImage: faker.internet.avatar(),                                                                    // 18
          category: {                                                                                            // 19
            name: 'new',                                                                                         // 20
            enteredAt: faker.date.recent()                                                                       // 21
          },                                                                                                     // 19
          imageUrl: faker.image.imageUrl()                                                                       // 23
        };                                                                                                       // 14
      }                                                                                                          // 25
                                                                                                                 //
      return model;                                                                                              // 9
    }()                                                                                                          // 9
  });                                                                                                            // 9
};                                                                                                               // 27
                                                                                                                 //
var createComments = function createComments() {                                                                 // 29
  var roasts = Roasts.find().fetch();                                                                            // 30
  _.each(roasts, function (roast) {                                                                              // 31
    Seed('comments', {                                                                                           // 32
      num: 10,                                                                                                   // 33
      ignoreExistingData: true,                                                                                  // 34
      environments: ['development'],                                                                             // 35
      model: function () {                                                                                       // 36
        function model(index) {                                                                                  // 32
          return {                                                                                               // 37
            content: faker.lorem.paragraph(),                                                                    // 38
            userId: faker.random.uuid(),                                                                         // 39
            userName: faker.internet.userName(),                                                                 // 40
            userImage: faker.internet.avatar(),                                                                  // 41
            roastId: roast._id                                                                                   // 42
          };                                                                                                     // 37
        }                                                                                                        // 44
                                                                                                                 //
        return model;                                                                                            // 32
      }()                                                                                                        // 32
    });                                                                                                          // 32
  });                                                                                                            // 46
};                                                                                                               // 47
                                                                                                                 //
var createReplies = function createReplies() {                                                                   // 49
  var comments = Comments.find().fetch();                                                                        // 50
  _.each(comments, function (comment) {                                                                          // 51
    Seed('comments', {                                                                                           // 52
      num: Math.floor(Math.random() * 5),                                                                        // 53
      ignoreExistingData: true,                                                                                  // 54
      environments: ['development'],                                                                             // 55
      model: function () {                                                                                       // 56
        function model(index) {                                                                                  // 52
          return {                                                                                               // 57
            content: faker.lorem.paragraph(),                                                                    // 58
            userId: faker.random.uuid(),                                                                         // 59
            userName: faker.internet.userName(),                                                                 // 60
            userImage: faker.internet.avatar(),                                                                  // 61
            roastId: comment.roastId,                                                                            // 62
            replyTo: comment._id                                                                                 // 63
          };                                                                                                     // 57
        }                                                                                                        // 65
                                                                                                                 //
        return model;                                                                                            // 52
      }()                                                                                                        // 52
    });                                                                                                          // 52
  });                                                                                                            // 67
};                                                                                                               // 68
                                                                                                                 //
Meteor.startup(function () {                                                                                     // 70
  /*Roasts.remove({});                                                                                           // 71
  Comments.remove({});*/                                                                                         //
                                                                                                                 //
  // use to migrate schema                                                                                       // 74
  // Roasts.find().fetch().forEach(roast => {                                                                    // 75
  //   if(typeof roast.category !== 'object')                                                                    // 76
  //     Roasts.update({ _id: roast._id }, { $set: { category: { name: 'new', enteredAt: roast.createdAt } } });
  // })                                                                                                          // 78
                                                                                                                 //
  if (Roasts.find().count() < 1 && Comments.find().count() < 1 && process.env.NODE_ENV === 'development') {      // 80
    createRoasts();                                                                                              // 81
    createComments();                                                                                            // 82
    createReplies();                                                                                             // 83
  }                                                                                                              // 84
});                                                                                                              // 85
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"publications.js":["meteor/meteor","meteor/check","../roasts-collection","../comments-collection",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// imports/modules/roasts/server/publications.js                                                                 //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var check;module.import('meteor/check',{"check":function(v){check=v}});var Roasts;module.import('../roasts-collection',{"Roasts":function(v){Roasts=v}});var Comments;module.import('../comments-collection',{"Comments":function(v){Comments=v}});
                                                                                                                 // 2
                                                                                                                 //
                                                                                                                 // 4
                                                                                                                 // 5
                                                                                                                 //
// ----------------- Roasts -----------------                                                                    // 7
                                                                                                                 //
Meteor.publish('roasts.hot', function (limit) {                                                                  // 9
  check(limit, Number);                                                                                          // 10
  return Roasts.find({                                                                                           // 11
    status: 'accepted',                                                                                          // 12
    "category.name": 'hot'                                                                                       // 13
  }, {                                                                                                           // 11
    sort: { createdAt: -1 },                                                                                     // 15
    limit: limit,                                                                                                // 16
    fields: {                                                                                                    // 17
      status: 0,                                                                                                 // 18
      createdAt: 0,                                                                                              // 19
      updatedAt: 0                                                                                               // 20
    }                                                                                                            // 17
  });                                                                                                            // 14
});                                                                                                              // 23
                                                                                                                 //
Meteor.publish('roasts.trending', function (limit) {                                                             // 25
  check(limit, Number);                                                                                          // 26
  return Roasts.find({                                                                                           // 27
    status: 'accepted',                                                                                          // 28
    "category.name": 'trending'                                                                                  // 29
  }, {                                                                                                           // 27
    sort: { createdAt: -1 },                                                                                     // 31
    limit: limit,                                                                                                // 32
    fields: {                                                                                                    // 33
      status: 0,                                                                                                 // 34
      createdAt: 0,                                                                                              // 35
      updatedAt: 0                                                                                               // 36
    }                                                                                                            // 33
  });                                                                                                            // 30
});                                                                                                              // 39
                                                                                                                 //
Meteor.publish('roasts.new', function (limit) {                                                                  // 41
  check(limit, Number);                                                                                          // 42
  return Roasts.find({                                                                                           // 43
    status: 'accepted',                                                                                          // 44
    "category.name": 'new'                                                                                       // 45
  }, {                                                                                                           // 43
    sort: { createdAt: -1 },                                                                                     // 47
    limit: limit,                                                                                                // 48
    fields: {                                                                                                    // 49
      status: 0,                                                                                                 // 50
      createdAt: 0,                                                                                              // 51
      updatedAt: 0                                                                                               // 52
    }                                                                                                            // 49
  });                                                                                                            // 46
});                                                                                                              // 55
                                                                                                                 //
Meteor.publish('roasts.single', function (roastId) {                                                             // 57
  check(roastId, String);                                                                                        // 58
  return Roasts.find({                                                                                           // 59
    _id: roastId,                                                                                                // 60
    status: 'accepted'                                                                                           // 61
  }, {                                                                                                           // 59
    fields: {                                                                                                    // 63
      status: 0,                                                                                                 // 64
      createdAt: 0,                                                                                              // 65
      updatedAt: 0                                                                                               // 66
    }                                                                                                            // 63
  });                                                                                                            // 62
});                                                                                                              // 69
                                                                                                                 //
Meteor.publish('roasts.all.user', function (userId) {                                                            // 71
  check(userId, String);                                                                                         // 72
  return Roasts.find({                                                                                           // 73
    userId: userId,                                                                                              // 74
    status: 'accepted'                                                                                           // 75
  }, {                                                                                                           // 73
    fields: {                                                                                                    // 77
      status: 0,                                                                                                 // 78
      createdAt: 0,                                                                                              // 79
      updatedAt: 0                                                                                               // 80
    }                                                                                                            // 77
  });                                                                                                            // 76
});                                                                                                              // 83
                                                                                                                 //
Meteor.publish('roasts.admin.queued', function () {                                                              // 85
  return Roasts.find({ status: 'queued' }, { sort: { createdAt: 1 } });                                          // 86
});                                                                                                              // 87
                                                                                                                 //
if (Meteor.isServer) {                                                                                           // 89
  Roasts._ensureIndex({ status: 1, totalUpvotes: 1 });                                                           // 90
  Roasts._ensureIndex({ status: 1, totalComments: 1 });                                                          // 91
  Roasts._ensureIndex({ status: 1, createdAt: 1 });                                                              // 92
  Roasts._ensureIndex({ _id: 1, status: 1 });                                                                    // 93
  Roasts._ensureIndex({ userId: 1, status: 1 });                                                                 // 94
  Roasts._ensureIndex({ _id: 1, userId: 1 });                                                                    // 95
  Roasts._ensureIndex({ status: 1, "category.name": 1, "category.enteredAt": 1 });                               // 96
}                                                                                                                // 97
                                                                                                                 //
// ----------------- Comments -----------------                                                                  // 100
                                                                                                                 //
Meteor.publish('comments.all.roastneighbours', function (roastId) {                                              // 102
  check(roastId, String);                                                                                        // 103
  var comments = Comments.find({                                                                                 // 104
    roastId: roastId                                                                                             // 105
  }, {                                                                                                           // 104
    fields: {                                                                                                    // 107
      updatedAt: 0                                                                                               // 108
    }                                                                                                            // 107
  });                                                                                                            // 106
  var roast = Roasts.findOne({ _id: roastId }, { fields: { status: 0, createdAt: 0, updatedAt: 0 } });           // 111
  var pub = [comments];                                                                                          // 112
  if (roast) {                                                                                                   // 113
    this.added('roasts', roast._id, roast);                                                                      // 114
    roastNext = Roasts.findOne({                                                                                 // 115
      _id: { $ne: roast._id },                                                                                   // 116
      "category.name": roast.category.name,                                                                      // 117
      "category.enteredAt": { $lt: roast.category.enteredAt },                                                   // 118
      status: 'accepted'                                                                                         // 119
    }, {                                                                                                         // 115
      sort: { "category.enteredAt": -1 },                                                                        // 121
      fields: { _id: 1, "category.enteredAt": 1 }                                                                // 122
    });                                                                                                          // 120
    if (roastNext) this.added('roasts', roastNext._id, roastNext);                                               // 124
    roastPrev = Roasts.findOne({                                                                                 // 125
      _id: { $ne: roast._id },                                                                                   // 126
      "category.name": roast.category.name,                                                                      // 127
      "category.enteredAt": { $gt: roast.category.enteredAt },                                                   // 128
      status: 'accepted'                                                                                         // 129
    }, {                                                                                                         // 125
      sort: { "category.enteredAt": 1 },                                                                         // 131
      fields: { _id: 1, "category.enteredAt": 1 }                                                                // 132
    });                                                                                                          // 130
    if (roastPrev) this.added('roasts', roastPrev._id, roastPrev);                                               // 134
  }                                                                                                              // 135
  this.ready();                                                                                                  // 136
  return pub;                                                                                                    // 137
});                                                                                                              // 138
                                                                                                                 //
Meteor.publish('comments.roast.top', function (roastId) {                                                        // 140
  check(roastId, String);                                                                                        // 141
  return Comments.find({                                                                                         // 142
    roastId: roastId,                                                                                            // 143
    replyTo: null                                                                                                // 144
  }, {                                                                                                           // 142
    sort: { points: -1 },                                                                                        // 146
    limit: 1,                                                                                                    // 147
    fields: {                                                                                                    // 148
      upvotes: 0,                                                                                                // 149
      downvotes: 0,                                                                                              // 150
      updatedAt: 0                                                                                               // 151
    }                                                                                                            // 148
  });                                                                                                            // 145
});                                                                                                              // 154
                                                                                                                 //
Meteor.publish('comments.all.user', function (userId) {                                                          // 156
  check(userId, String);                                                                                         // 157
  return Comments.find({                                                                                         // 158
    userId: userId,                                                                                              // 159
    replyTo: null                                                                                                // 160
  }, {                                                                                                           // 158
    sort: { points: -1 },                                                                                        // 162
    fields: {                                                                                                    // 163
      updatedAt: 0                                                                                               // 164
    }                                                                                                            // 163
  });                                                                                                            // 161
});                                                                                                              // 167
                                                                                                                 //
if (Meteor.isServer) {                                                                                           // 169
  Comments._ensureIndex({ replyTo: 1, points: 1, userId: 1, roastId: 1 });                                       // 170
  Comments._ensureIndex({ points: 1, userId: 1, roastId: 1, replyTo: 1 });                                       // 171
  Comments._ensureIndex({ userId: 1, replyTo: 1, points: 1 });                                                   // 172
  Comments._ensureIndex({ roastId: 1, replyTo: 1, points: 1 });                                                  // 173
}                                                                                                                // 174
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"roasts-methods.js":["meteor/meteor","meteor/check","meteor/underscore","/imports/modules/roasts/roasts-collection","/imports/modules/roasts/comments-collection","/imports/modules/utility/amazon-url-validity",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// imports/modules/roasts/server/roasts-methods.js                                                               //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var check;module.import('meteor/check',{"check":function(v){check=v}});var _;module.import('meteor/underscore',{"_":function(v){_=v}});var Roasts;module.import('/imports/modules/roasts/roasts-collection',{"Roasts":function(v){Roasts=v}});var Comments;module.import('/imports/modules/roasts/comments-collection',{"Comments":function(v){Comments=v}});var checkAmazonUrlValidity;module.import('/imports/modules/utility/amazon-url-validity',{"checkAmazonUrlValidity":function(v){checkAmazonUrlValidity=v}});
                                                                                                                 // 2
                                                                                                                 // 3
                                                                                                                 //
                                                                                                                 // 5
                                                                                                                 // 6
                                                                                                                 // 7
                                                                                                                 //
var getUserImage = function getUserImage(user) {                                                                 // 9
  if (user.services.facebook) {                                                                                  // 10
    return user.services.facebook.picture;                                                                       // 11
  } else if (user.services.google) {                                                                             // 12
    return user.services.google.picture;                                                                         // 13
  }                                                                                                              // 14
};                                                                                                               // 15
                                                                                                                 //
Meteor.methods({                                                                                                 // 17
  createRoast: function () {                                                                                     // 18
    function createRoast(imageUrl, title) {                                                                      // 17
      check(imageUrl, String);                                                                                   // 19
      check(title, String);                                                                                      // 20
      checkAmazonUrlValidity(imageUrl);                                                                          // 21
                                                                                                                 //
      if (!this.userId) return;                                                                                  // 23
      var user = Meteor.users.findOne(this.userId);                                                              // 24
      var userName = user.profile.username || user.profile.name;                                                 // 25
      var userImage = getUserImage(user);                                                                        // 26
                                                                                                                 //
      var roast = Roasts.findOne({ userId: this.userId, imageUrl: imageUrl });                                   // 28
      if (roast) throw new Meteor.Error("You already uploaded this file!");                                      // 29
                                                                                                                 //
      roast = {                                                                                                  // 31
        title: title,                                                                                            // 32
        userId: this.userId,                                                                                     // 33
        userName: userName,                                                                                      // 34
        userImage: userImage,                                                                                    // 35
        imageUrl: imageUrl                                                                                       // 36
      };                                                                                                         // 31
                                                                                                                 //
      return Roasts.insert(roast);                                                                               // 39
    }                                                                                                            // 40
                                                                                                                 //
    return createRoast;                                                                                          // 17
  }(),                                                                                                           // 17
  deleteRoast: function () {                                                                                     // 41
    function deleteRoast(roastId) {                                                                              // 17
      check(roastId, String);                                                                                    // 42
      if (!this.userId) return;                                                                                  // 43
      Roasts.update({ _id: roastId, userId: this.userId }, { $set: { status: 'deleted' } });                     // 44
    }                                                                                                            // 45
                                                                                                                 //
    return deleteRoast;                                                                                          // 17
  }(),                                                                                                           // 17
  createComment: function () {                                                                                   // 46
    function createComment(roastId, commentId, text) {                                                           // 17
      check(roastId, String);                                                                                    // 47
      check(commentId, Match.OneOf(String, null));                                                               // 48
      check(text, String);                                                                                       // 49
                                                                                                                 //
      //TODO: clean text!                                                                                        // 51
                                                                                                                 //
      if (!this.userId) return;                                                                                  // 53
      var user = Meteor.users.findOne(this.userId);                                                              // 54
                                                                                                                 //
      var roast = Roasts.findOne(roastId);                                                                       // 56
      if (!roast) return;                                                                                        // 57
                                                                                                                 //
      if (roast.status !== 'accepted') return;                                                                   // 59
                                                                                                                 //
      var comment = void 0;                                                                                      // 61
      if (commentId) {                                                                                           // 62
        comment = Comments.findOne(commentId);                                                                   // 63
        if (!comment) return;                                                                                    // 64
      }                                                                                                          // 65
                                                                                                                 //
      var userImage = getUserImage(user);                                                                        // 67
                                                                                                                 //
      var newComment = {                                                                                         // 69
        content: text,                                                                                           // 70
        userId: user._id,                                                                                        // 71
        userName: user.profile.username || user.profile.name,                                                    // 72
        userImage: userImage,                                                                                    // 73
        roastId: roastId,                                                                                        // 74
        replyTo: commentId || undefined                                                                          // 75
      };                                                                                                         // 69
                                                                                                                 //
      Comments.insert(newComment);                                                                               // 78
    }                                                                                                            // 79
                                                                                                                 //
    return createComment;                                                                                        // 17
  }(),                                                                                                           // 17
  upvoteComment: function () {                                                                                   // 80
    function upvoteComment(commentId) {                                                                          // 17
      check(commentId, String);                                                                                  // 81
                                                                                                                 //
      if (!this.userId) return;                                                                                  // 83
      var userId = this.userId;                                                                                  // 84
                                                                                                                 //
      var comment = Comments.findOne(commentId);                                                                 // 86
      if (!comment) return;                                                                                      // 87
                                                                                                                 //
      // prevent voting own comments                                                                             // 89
      if (comment.userId === userId) return;                                                                     // 90
                                                                                                                 //
      var roast = Roasts.findOne({ _id: comment.roastId });                                                      // 92
      if (!roast) return;                                                                                        // 93
                                                                                                                 //
      var points = comment.points;                                                                               // 95
      var roastPoints = roast.totalUpvotes - points;                                                             // 96
                                                                                                                 //
      // revert upvote if clicked twice                                                                          // 98
      var upvote = _.findWhere(comment.upvotes, { userId: userId });                                             // 99
      var downvote = _.findWhere(comment.downvotes, { userId: userId });                                         // 100
      if (upvote) {                                                                                              // 101
        points = Math.max(0, points - 1);                                                                        // 102
        Comments.update({ _id: commentId }, {                                                                    // 103
          $pull: { upvotes: upvote },                                                                            // 104
          $set: { points: points }                                                                               // 105
        });                                                                                                      // 103
      } else if (downvote) {                                                                                     // 107
        points += 2;                                                                                             // 108
        Comments.update({ _id: commentId }, {                                                                    // 109
          $push: { upvotes: { userId: userId, createdAt: new Date() } },                                         // 110
          $pull: { downvotes: downvote },                                                                        // 111
          $set: { points: points }                                                                               // 112
        });                                                                                                      // 109
      } else {                                                                                                   // 114
        points++;                                                                                                // 115
        Comments.update({ _id: commentId }, {                                                                    // 116
          $push: { upvotes: { userId: userId, createdAt: new Date() } },                                         // 117
          $set: { points: points }                                                                               // 118
        });                                                                                                      // 116
      }                                                                                                          // 120
                                                                                                                 //
      roastPoints += points;                                                                                     // 122
      Roasts.update({ _id: roast._id }, { $set: { totalUpvotes: roastPoints } });                                // 123
    }                                                                                                            // 124
                                                                                                                 //
    return upvoteComment;                                                                                        // 17
  }(),                                                                                                           // 17
  downvoteComment: function () {                                                                                 // 125
    function downvoteComment(commentId) {                                                                        // 17
      check(commentId, String);                                                                                  // 126
                                                                                                                 //
      if (!this.userId) return;                                                                                  // 128
      var userId = this.userId;                                                                                  // 129
                                                                                                                 //
      var comment = Comments.findOne(commentId);                                                                 // 131
      if (!comment) return;                                                                                      // 132
                                                                                                                 //
      // prevent downvoting own comments                                                                         // 134
      if (comment.userId === userId) return;                                                                     // 135
                                                                                                                 //
      var roast = Roasts.findOne({ _id: comment.roastId });                                                      // 137
      if (!roast) return;                                                                                        // 138
                                                                                                                 //
      var points = comment.points;                                                                               // 140
      var roastPoints = roast.totalUpvotes - points;                                                             // 141
                                                                                                                 //
      // revert downvote if clicked twice                                                                        // 143
      var upvote = _.findWhere(comment.upvotes, { userId: userId });                                             // 144
      var downvote = _.findWhere(comment.downvotes, { userId: userId });                                         // 145
      if (downvote) {                                                                                            // 146
        points++;                                                                                                // 147
        Comments.update({ _id: commentId }, {                                                                    // 148
          $pull: { downvotes: downvote },                                                                        // 149
          $set: { points: points }                                                                               // 150
        });                                                                                                      // 148
      } else if (upvote && points > 1) {                                                                         // 152
        points = Math.max(0, points - 2);                                                                        // 153
        Comments.update({ _id: commentId }, {                                                                    // 154
          $pull: { upvotes: upvote },                                                                            // 155
          $push: { downvotes: { userId: userId, createdAt: new Date() } },                                       // 156
          $set: { points: points }                                                                               // 157
        });                                                                                                      // 154
      } else if (upvote && points <= 1) {                                                                        // 159
        points = Math.max(0, points - 1);                                                                        // 160
        Comments.update({ _id: commentId }, {                                                                    // 161
          $pull: { upvotes: upvote },                                                                            // 162
          $set: { points: points }                                                                               // 163
        });                                                                                                      // 161
      } else {                                                                                                   // 165
        points = Math.max(0, points - 1);                                                                        // 166
        Comments.update({ _id: commentId }, {                                                                    // 167
          $push: { downvotes: { userId: userId, createdAt: new Date() } },                                       // 168
          $set: { points: points }                                                                               // 169
        });                                                                                                      // 167
      }                                                                                                          // 171
                                                                                                                 //
      roastPoints += points;                                                                                     // 173
      Roasts.update({ _id: roast._id }, { $set: { totalUpvotes: roastPoints } });                                // 174
    }                                                                                                            // 175
                                                                                                                 //
    return downvoteComment;                                                                                      // 17
  }(),                                                                                                           // 17
  acceptRoast: function () {                                                                                     // 176
    function acceptRoast(roastId) {                                                                              // 17
      check(roastId, String);                                                                                    // 177
                                                                                                                 //
      if (!this.userId) return;                                                                                  // 179
      if (!Roles.userIsInRole(this.userId, 'admin')) return;                                                     // 180
                                                                                                                 //
      var roast = Roasts.findOne({ _id: roastId, status: { $ne: 'accepted' } });                                 // 182
      if (!roast) return;                                                                                        // 183
                                                                                                                 //
      Roasts.update({ _id: roastId }, { $set: { status: 'accepted' } });                                         // 185
    }                                                                                                            // 186
                                                                                                                 //
    return acceptRoast;                                                                                          // 17
  }(),                                                                                                           // 17
  declineRoast: function () {                                                                                    // 187
    function declineRoast(roastId) {                                                                             // 17
      check(roastId, String);                                                                                    // 188
                                                                                                                 //
      if (!this.userId) return;                                                                                  // 190
      if (!Roles.userIsInRole(this.userId, 'admin')) return;                                                     // 191
                                                                                                                 //
      var roast = Roasts.findOne({ _id: roastId, status: { $ne: 'declined' } });                                 // 193
      if (!roast) return;                                                                                        // 194
                                                                                                                 //
      Roasts.update({ _id: roastId }, { $set: { status: 'declined' } });                                         // 196
    }                                                                                                            // 197
                                                                                                                 //
    return declineRoast;                                                                                         // 17
  }()                                                                                                            // 17
});                                                                                                              // 17
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"comments-collection.js":["meteor/aldeed:simple-schema","/imports/modules/utility/schema-commons.js","./roasts-collection",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// imports/modules/roasts/comments-collection.js                                                                 //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
module.export({Comments:function(){return Comments}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var SchemaCommons;module.import('/imports/modules/utility/schema-commons.js',{"SchemaCommons":function(v){SchemaCommons=v}});var Roasts;module.import('./roasts-collection',{"Roasts":function(v){Roasts=v}});
                                                                                                                 //
                                                                                                                 // 3
                                                                                                                 // 4
                                                                                                                 //
var CommentsSchema = new SimpleSchema({                                                                          // 6
  content: {                                                                                                     // 7
    type: String,                                                                                                // 8
    max: 500                                                                                                     // 9
  },                                                                                                             // 7
  replyTo: {                                                                                                     // 11
    type: String,                                                                                                // 12
    optional: true                                                                                               // 13
  },                                                                                                             // 11
  upvotes: {                                                                                                     // 15
    type: [Object],                                                                                              // 16
    autoValue: function () {                                                                                     // 17
      function autoValue() {                                                                                     // 15
        if (this.isInsert) {                                                                                     // 18
          return [];                                                                                             // 19
        }                                                                                                        // 20
      }                                                                                                          // 21
                                                                                                                 //
      return autoValue;                                                                                          // 15
    }()                                                                                                          // 15
  },                                                                                                             // 15
  "upvotes.$.userId": {                                                                                          // 23
    type: String                                                                                                 // 24
  },                                                                                                             // 23
  "upvotes.$.createdAt": {                                                                                       // 26
    type: Date,                                                                                                  // 27
    autoValue: function () {                                                                                     // 28
      function autoValue() {                                                                                     // 26
        if (this.isInsert) {                                                                                     // 29
          return new Date();                                                                                     // 30
        }                                                                                                        // 31
      }                                                                                                          // 32
                                                                                                                 //
      return autoValue;                                                                                          // 26
    }()                                                                                                          // 26
  },                                                                                                             // 26
  downvotes: {                                                                                                   // 34
    type: [Object],                                                                                              // 35
    autoValue: function () {                                                                                     // 36
      function autoValue() {                                                                                     // 34
        if (this.isInsert) {                                                                                     // 37
          return [];                                                                                             // 38
        }                                                                                                        // 39
      }                                                                                                          // 40
                                                                                                                 //
      return autoValue;                                                                                          // 34
    }()                                                                                                          // 34
  },                                                                                                             // 34
  "downvotes.$.userId": {                                                                                        // 42
    type: String                                                                                                 // 43
  },                                                                                                             // 42
  "downvotes.$.createdAt": {                                                                                     // 45
    type: Date,                                                                                                  // 46
    autoValue: function () {                                                                                     // 47
      function autoValue() {                                                                                     // 45
        if (this.isInsert) {                                                                                     // 48
          return new Date();                                                                                     // 49
        }                                                                                                        // 50
      }                                                                                                          // 51
                                                                                                                 //
      return autoValue;                                                                                          // 45
    }()                                                                                                          // 45
  },                                                                                                             // 45
  points: {                                                                                                      // 53
    type: Number,                                                                                                // 54
    autoValue: function () {                                                                                     // 55
      function autoValue() {                                                                                     // 53
        if (this.isInsert) {                                                                                     // 56
          return 0;                                                                                              // 57
        }                                                                                                        // 58
      }                                                                                                          // 59
                                                                                                                 //
      return autoValue;                                                                                          // 53
    }()                                                                                                          // 53
  },                                                                                                             // 53
  userId: {                                                                                                      // 61
    type: String                                                                                                 // 62
  },                                                                                                             // 61
  userName: {                                                                                                    // 64
    type: String                                                                                                 // 65
  },                                                                                                             // 64
  userImage: {                                                                                                   // 67
    type: String                                                                                                 // 68
  },                                                                                                             // 67
  roastId: {                                                                                                     // 70
    type: String                                                                                                 // 71
  },                                                                                                             // 70
  createdAt: SchemaCommons.createdAt,                                                                            // 73
  updatedAt: SchemaCommons.updatedAt                                                                             // 74
});                                                                                                              // 6
                                                                                                                 //
var Comments = new Mongo.Collection('comments');                                                                 // 77
                                                                                                                 //
Comments.allow({                                                                                                 // 79
  insert: function () {                                                                                          // 80
    function insert() {                                                                                          // 80
      return false;                                                                                              // 80
    }                                                                                                            // 80
                                                                                                                 //
    return insert;                                                                                               // 80
  }(),                                                                                                           // 80
  update: function () {                                                                                          // 81
    function update() {                                                                                          // 81
      return false;                                                                                              // 81
    }                                                                                                            // 81
                                                                                                                 //
    return update;                                                                                               // 81
  }(),                                                                                                           // 81
  remove: function () {                                                                                          // 82
    function remove() {                                                                                          // 82
      return false;                                                                                              // 82
    }                                                                                                            // 82
                                                                                                                 //
    return remove;                                                                                               // 82
  }()                                                                                                            // 82
});                                                                                                              // 79
                                                                                                                 //
Comments.deny({                                                                                                  // 85
  insert: function () {                                                                                          // 86
    function insert() {                                                                                          // 86
      return true;                                                                                               // 86
    }                                                                                                            // 86
                                                                                                                 //
    return insert;                                                                                               // 86
  }(),                                                                                                           // 86
  update: function () {                                                                                          // 87
    function update() {                                                                                          // 87
      return true;                                                                                               // 87
    }                                                                                                            // 87
                                                                                                                 //
    return update;                                                                                               // 87
  }(),                                                                                                           // 87
  remove: function () {                                                                                          // 88
    function remove() {                                                                                          // 88
      return true;                                                                                               // 88
    }                                                                                                            // 88
                                                                                                                 //
    return remove;                                                                                               // 88
  }()                                                                                                            // 88
});                                                                                                              // 85
                                                                                                                 //
Comments.attachSchema(CommentsSchema);                                                                           // 91
                                                                                                                 //
Comments.after.insert(function (userId, doc) {                                                                   // 93
  Roasts.update({ _id: doc.roastId }, { $inc: { totalComments: 1 } });                                           // 94
});                                                                                                              // 95
                                                                                                                 //
Comments.after.remove(function (userId, doc) {                                                                   // 97
  Roasts.update({ _id: doc.roastId }, { $inc: { totalComments: -1 } });                                          // 98
});                                                                                                              // 99
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"roasts-collection.js":["meteor/aldeed:simple-schema","/imports/modules/utility/schema-commons.js",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// imports/modules/roasts/roasts-collection.js                                                                   //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
module.export({Roasts:function(){return Roasts}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var SchemaCommons;module.import('/imports/modules/utility/schema-commons.js',{"SchemaCommons":function(v){SchemaCommons=v}});
                                                                                                                 //
                                                                                                                 // 3
                                                                                                                 //
var RoastsSchema = new SimpleSchema({                                                                            // 5
  title: {                                                                                                       // 6
    type: String                                                                                                 // 7
  },                                                                                                             // 6
  userId: {                                                                                                      // 9
    type: String                                                                                                 // 10
  },                                                                                                             // 9
  userName: {                                                                                                    // 12
    type: String                                                                                                 // 13
  },                                                                                                             // 12
  userImage: {                                                                                                   // 15
    type: String                                                                                                 // 16
  },                                                                                                             // 15
  imageUrl: {                                                                                                    // 18
    type: String                                                                                                 // 19
  },                                                                                                             // 18
  status: {                                                                                                      // 21
    type: String,                                                                                                // 22
    allowedValues: ['queued', 'accepted', 'declined', 'banned', 'deleted'],                                      // 23
    autoValue: function () {                                                                                     // 24
      function autoValue() {                                                                                     // 21
        if (this.isInsert) {                                                                                     // 25
          return 'queued';                                                                                       // 26
        }                                                                                                        // 27
      }                                                                                                          // 28
                                                                                                                 //
      return autoValue;                                                                                          // 21
    }()                                                                                                          // 21
  },                                                                                                             // 21
  category: {                                                                                                    // 30
    type: Object                                                                                                 // 31
  },                                                                                                             // 30
  "category.name": {                                                                                             // 33
    type: String,                                                                                                // 34
    allowedValues: ['new', 'trending', 'hot'],                                                                   // 35
    autoValue: function () {                                                                                     // 36
      function autoValue() {                                                                                     // 33
        if (this.isInsert) {                                                                                     // 37
          return 'new';                                                                                          // 38
        }                                                                                                        // 39
      }                                                                                                          // 40
                                                                                                                 //
      return autoValue;                                                                                          // 33
    }()                                                                                                          // 33
  },                                                                                                             // 33
  "category.enteredAt": {                                                                                        // 42
    type: Date,                                                                                                  // 43
    autoValue: function () {                                                                                     // 44
      function autoValue() {                                                                                     // 42
        if (this.isInsert) {                                                                                     // 45
          return new Date();                                                                                     // 46
        }                                                                                                        // 47
      }                                                                                                          // 48
                                                                                                                 //
      return autoValue;                                                                                          // 42
    }()                                                                                                          // 42
  },                                                                                                             // 42
  totalUpvotes: {                                                                                                // 50
    type: Number,                                                                                                // 51
    autoValue: function () {                                                                                     // 52
      function autoValue() {                                                                                     // 50
        if (this.isInsert) {                                                                                     // 53
          return 0;                                                                                              // 54
        }                                                                                                        // 55
      }                                                                                                          // 56
                                                                                                                 //
      return autoValue;                                                                                          // 50
    }()                                                                                                          // 50
  },                                                                                                             // 50
  totalComments: {                                                                                               // 58
    type: Number,                                                                                                // 59
    autoValue: function () {                                                                                     // 60
      function autoValue() {                                                                                     // 58
        if (this.isInsert) {                                                                                     // 61
          return 0;                                                                                              // 62
        }                                                                                                        // 63
      }                                                                                                          // 64
                                                                                                                 //
      return autoValue;                                                                                          // 58
    }()                                                                                                          // 58
  },                                                                                                             // 58
  createdAt: SchemaCommons.createdAt,                                                                            // 66
  updatedAt: SchemaCommons.updatedAt                                                                             // 67
});                                                                                                              // 5
                                                                                                                 //
var Roasts = new Mongo.Collection('roasts');                                                                     // 70
                                                                                                                 //
Roasts.allow({                                                                                                   // 72
  insert: function () {                                                                                          // 73
    function insert() {                                                                                          // 73
      return false;                                                                                              // 73
    }                                                                                                            // 73
                                                                                                                 //
    return insert;                                                                                               // 73
  }(),                                                                                                           // 73
  update: function () {                                                                                          // 74
    function update() {                                                                                          // 74
      return false;                                                                                              // 74
    }                                                                                                            // 74
                                                                                                                 //
    return update;                                                                                               // 74
  }(),                                                                                                           // 74
  remove: function () {                                                                                          // 75
    function remove() {                                                                                          // 75
      return false;                                                                                              // 75
    }                                                                                                            // 75
                                                                                                                 //
    return remove;                                                                                               // 75
  }()                                                                                                            // 75
});                                                                                                              // 72
                                                                                                                 //
Roasts.deny({                                                                                                    // 78
  insert: function () {                                                                                          // 79
    function insert() {                                                                                          // 79
      return true;                                                                                               // 79
    }                                                                                                            // 79
                                                                                                                 //
    return insert;                                                                                               // 79
  }(),                                                                                                           // 79
  update: function () {                                                                                          // 80
    function update() {                                                                                          // 80
      return true;                                                                                               // 80
    }                                                                                                            // 80
                                                                                                                 //
    return update;                                                                                               // 80
  }(),                                                                                                           // 80
  remove: function () {                                                                                          // 81
    function remove() {                                                                                          // 81
      return true;                                                                                               // 81
    }                                                                                                            // 81
                                                                                                                 //
    return remove;                                                                                               // 81
  }()                                                                                                            // 81
});                                                                                                              // 78
                                                                                                                 //
Roasts.attachSchema(RoastsSchema);                                                                               // 84
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"slingshot-filerestrictions.js":["meteor/edgee:slingshot",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// imports/modules/roasts/slingshot-filerestrictions.js                                                          //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
var Slingshot;module.import('meteor/edgee:slingshot',{"Slingshot":function(v){Slingshot=v}});                    // 1
                                                                                                                 //
Slingshot.fileRestrictions("uploadRoastImgS3", {                                                                 // 3
  allowedFileTypes: ["image/png", "image/jpeg", "image/gif"],                                                    // 4
  maxSize: 8 * 1024 * 1024 });                                                                                   // 5
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"utility":{"amazon-url-validity.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// imports/modules/utility/amazon-url-validity.js                                                                //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
module.export({checkAmazonUrlValidity:function(){return checkAmazonUrlValidity}});var checkAmazonUrlValidity = function checkAmazonUrlValidity(url) {
  var test = { valid: true };                                                                                    // 2
  if (url.indexOf('itsroastme.s3-eu-central-1.amazonaws.com') < 0) {                                             // 3
    test.valid = false;                                                                                          // 4
    test.error = "Url \"" + url + "\" is not a valid amazonaws url!";                                            // 5
  }                                                                                                              // 6
                                                                                                                 //
  if (!test.valid) {                                                                                             // 8
    throw new Meteor.Error("file-error", test.error);                                                            // 9
  }                                                                                                              // 10
};                                                                                                               // 11
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"schema-commons.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// imports/modules/utility/schema-commons.js                                                                     //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
module.export({SchemaCommons:function(){return SchemaCommons}});var SchemaCommons = {                            // 1
  createdAt: {                                                                                                   // 2
    type: Date,                                                                                                  // 3
    autoValue: function () {                                                                                     // 4
      function autoValue() {                                                                                     // 2
        if (this.isInsert) {                                                                                     // 5
          return new Date();                                                                                     // 6
        } else if (this.isUpsert) {                                                                              // 7
          return { $setOnInsert: new Date() };                                                                   // 8
        }                                                                                                        // 9
        this.unset();                                                                                            // 10
      }                                                                                                          // 11
                                                                                                                 //
      return autoValue;                                                                                          // 2
    }()                                                                                                          // 2
  },                                                                                                             // 2
  updatedAt: {                                                                                                   // 13
    type: Date,                                                                                                  // 14
    autoValue: function () {                                                                                     // 15
      function autoValue() {                                                                                     // 13
        if (this.isUpdate) {                                                                                     // 16
          return new Date();                                                                                     // 17
        } else if (this.isUpsert) {                                                                              // 18
          return { $setOnUpdate: new Date() };                                                                   // 19
        }                                                                                                        // 20
      }                                                                                                          // 21
                                                                                                                 //
      return autoValue;                                                                                          // 13
    }(),                                                                                                         // 13
                                                                                                                 //
    denyInsert: true,                                                                                            // 22
    optional: true                                                                                               // 23
  }                                                                                                              // 13
};                                                                                                               // 1
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"seeder.js":["babel-runtime/helpers/classCallCheck","meteor/meteor",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// imports/modules/utility/seeder.js                                                                             //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
var _classCallCheck;module.import('babel-runtime/helpers/classCallCheck',{"default":function(v){_classCallCheck=v}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});
                                                                                                                 // 1
                                                                                                                 //
var Seeder = function () {                                                                                       //
  function Seeder(collectionName, options) {                                                                     // 4
    _classCallCheck(this, Seeder);                                                                               // 4
                                                                                                                 //
    if (!collectionName || !options) {                                                                           // 5
      throw new Error('Wrong Seeder usage! Please supply a collection name and some options.');                  // 6
    } else {                                                                                                     // 7
      this.collection = this.getCollection(collectionName);                                                      // 8
      this.options = options;                                                                                    // 9
                                                                                                                 //
      if (typeof this.collection !== 'undefined') {                                                              // 11
        this.seed();                                                                                             // 12
      } else {                                                                                                   // 13
        throw new Error('Could not find a collection called "' + collectionName + '"');                          // 14
      }                                                                                                          // 15
    }                                                                                                            // 16
  }                                                                                                              // 17
                                                                                                                 //
  Seeder.prototype.getCollection = function () {                                                                 //
    function getCollection(collectionName) {                                                                     //
      return collectionName === 'Users' ? Meteor.users : Mongo.Collection.get(collectionName);                   // 20
    }                                                                                                            // 21
                                                                                                                 //
    return getCollection;                                                                                        //
  }();                                                                                                           //
                                                                                                                 //
  Seeder.prototype.seed = function () {                                                                          //
    function seed() {                                                                                            //
      var options = this.options,                                                                                // 24
          data = options.data,                                                                                   // 24
          model = options.model;                                                                                 // 24
                                                                                                                 //
      if (data && !model) this.sow(data);                                                                        // 28
      if (model && !data) this.sow(model);                                                                       // 29
    }                                                                                                            // 30
                                                                                                                 //
    return seed;                                                                                                 //
  }();                                                                                                           //
                                                                                                                 //
  Seeder.prototype.sow = function () {                                                                           //
    function sow(data) {                                                                                         //
      var isDataArray = data instanceof Array,                                                                   // 33
          loopLength = isDataArray ? data.length : this.options.num,                                             // 33
          hasData = this.options.ignoreExistingData ? false : this.checkForExistingData(),                       // 33
          collectionName = this.collection._name,                                                                // 33
          isUsers = collectionName === 'users',                                                                  // 33
          environmentAllowed = this.environmentAllowed();                                                        // 33
                                                                                                                 //
      if (!hasData && environmentAllowed) {                                                                      // 40
        for (var i = 0; i < loopLength; i++) {                                                                   // 41
          var value = isDataArray ? data[i] : data(i);                                                           // 42
                                                                                                                 //
          if (!isUsers) {                                                                                        // 44
            this.collection.insert(value);                                                                       // 45
          } else {                                                                                               // 46
            console.log('Seeding users is not supported!');                                                      // 47
          }                                                                                                      // 48
        }                                                                                                        // 49
      }                                                                                                          // 50
                                                                                                                 //
      if (hasData) {                                                                                             // 52
        console.log('The ' + collectionName + ' collection already contains data!');                             // 53
      }                                                                                                          // 54
      if (!environmentAllowed) {                                                                                 // 55
        console.log('Seeding in ' + process.env.NODE_ENV + ' is not allowed!');                                  // 56
      }                                                                                                          // 57
    }                                                                                                            // 58
                                                                                                                 //
    return sow;                                                                                                  //
  }();                                                                                                           //
                                                                                                                 //
  Seeder.prototype.checkForExistingData = function () {                                                          //
    function checkForExistingData() {                                                                            //
      var existingCount = this.collection.find().count();                                                        // 61
      return this.options.num ? existingCount >= this.options.num : existingCount > 0;                           // 62
    }                                                                                                            // 63
                                                                                                                 //
    return checkForExistingData;                                                                                 //
  }();                                                                                                           //
                                                                                                                 //
  Seeder.prototype.environmentAllowed = function () {                                                            //
    function environmentAllowed() {                                                                              //
      var environments = this.options.environments;                                                              // 66
                                                                                                                 //
      if (environments) {                                                                                        // 68
        return environments.indexOf(process.env.NODE_ENV) > -1;                                                  // 69
      } else {                                                                                                   // 70
        return true;                                                                                             // 71
      }                                                                                                          // 72
    }                                                                                                            // 73
                                                                                                                 //
    return environmentAllowed;                                                                                   //
  }();                                                                                                           //
                                                                                                                 //
  return Seeder;                                                                                                 //
}();                                                                                                             //
                                                                                                                 //
module.export("default",exports.default=(Seed = function Seed(collection, options) {                             // 76
  return new Seeder(collection, options);                                                                        // 77
}));                                                                                                             // 78
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},"startup":{"server":{"index.js":["/imports/modules/accounts/server/configure-services","/imports/modules/accounts/server/publications","/imports/modules/accounts/server/users-schema","/imports/modules/accounts/server/social-login-helpers","/imports/modules/accounts/server/methods","/imports/modules/roasts/roasts-collection","/imports/modules/roasts/comments-collection","/imports/modules/roasts/slingshot-filerestrictions","/imports/modules/roasts/server/roasts-methods","/imports/modules/roasts/server/publications","/imports/modules/roasts/server/fixtures","/imports/modules/roasts/server/configure-slingshot","/imports/modules/admin/server/fixtures","/imports/modules/admin/server/publications",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// imports/startup/server/index.js                                                                               //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
module.import('/imports/modules/accounts/server/configure-services');module.import('/imports/modules/accounts/server/publications');module.import('/imports/modules/accounts/server/users-schema');module.import('/imports/modules/accounts/server/social-login-helpers');module.import('/imports/modules/accounts/server/methods');module.import('/imports/modules/roasts/roasts-collection');module.import('/imports/modules/roasts/comments-collection');module.import('/imports/modules/roasts/slingshot-filerestrictions');module.import('/imports/modules/roasts/server/roasts-methods');module.import('/imports/modules/roasts/server/publications');module.import('/imports/modules/roasts/server/fixtures');module.import('/imports/modules/roasts/server/configure-slingshot');module.import('/imports/modules/admin/server/fixtures');module.import('/imports/modules/admin/server/publications');
                                                                                                                 // 2
                                                                                                                 // 3
                                                                                                                 // 4
                                                                                                                 // 5
                                                                                                                 //
                                                                                                                 // 7
                                                                                                                 // 8
                                                                                                                 // 9
                                                                                                                 // 10
                                                                                                                 // 11
                                                                                                                 // 12
                                                                                                                 // 13
                                                                                                                 //
                                                                                                                 // 15
                                                                                                                 // 16
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}}},"server":{"main.js":["/imports/startup/server",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// server/main.js                                                                                                //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
module.import('/imports/startup/server');                                                                        // 1
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json",".jsx"]});
require("./server/main.js");
//# sourceMappingURL=app.js.map
